package electricityBillingSystem;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class delete extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    delete frame = new delete();
                    frame.setLocationRelativeTo(null);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public delete() {
    	setTitle("Electricity Billing System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 403, 308);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 132));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Confirm your Name ");
        lblNewLabel.setFont(new Font("Georgia", Font.BOLD, 25));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setBounds(10, 11, 368, 38);
        contentPane.add(lblNewLabel);
        
        JLabel lblAndPassword = new JLabel("and Password");
        lblAndPassword.setHorizontalAlignment(SwingConstants.CENTER);
        lblAndPassword.setForeground(Color.WHITE);
        lblAndPassword.setFont(new Font("Georgia", Font.BOLD, 25));
        lblAndPassword.setBounds(10, 45, 368, 38);
        contentPane.add(lblAndPassword);
        
        JLabel lblNewLabel_1 = new JLabel("Name");
        lblNewLabel_1.setFont(new Font("SimSun", Font.BOLD, 20));
        lblNewLabel_1.setForeground(new Color(255, 255, 255));
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
        lblNewLabel_1.setBounds(59, 125, 89, 21);
        contentPane.add(lblNewLabel_1);
        
        JLabel lblNewLabel_1_1 = new JLabel("Password");
        lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
        lblNewLabel_1_1.setForeground(Color.WHITE);
        lblNewLabel_1_1.setFont(new Font("SimSun", Font.BOLD, 20));
        lblNewLabel_1_1.setBounds(59, 157, 89, 21);
        contentPane.add(lblNewLabel_1_1);
        
        textField = new JTextField();
        textField.setFont(new Font("SimSun", Font.BOLD, 14));
        textField.setBounds(178, 127, 120, 20);
        contentPane.add(textField);
        textField.setColumns(10);
        
        textField_1 = new JTextField();
        textField_1.setFont(new Font("SimSun", Font.BOLD, 14));
        textField_1.setColumns(10);
        textField_1.setBounds(178, 159, 120, 20);
        contentPane.add(textField_1);
        
        JButton btnDelete = new JButton("Delete");
        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = textField.getText().trim();
                String password = textField_1.getText().trim();

                if (!name.isEmpty() && !password.isEmpty()) {
                    if (validateCredentials(name, password)) {
                        if (deleteData(name)) {
                            JOptionPane.showMessageDialog(null, "Data associated with the name '" + name + "' has been deleted successfully.");
                            // Clear the text fields after successful deletion
                            textField.setText("");
                            textField_1.setText("");
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to delete data associated with the name '" + name + "'.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Incorrect name or password. Please try again.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter name and password.");
                }
            }
        });
        btnDelete.setForeground(Color.WHITE);
        btnDelete.setFont(new Font("SimSun", Font.BOLD, 14));
        btnDelete.setBackground(new Color(0, 0, 132));
        btnDelete.setBounds(129, 204, 101, 21);
        contentPane.add(btnDelete);
        
        JButton btnMenu = new JButton("Menu");
        btnMenu.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		menu menuform = new menu();
        		menuform.setLocationRelativeTo(null);
                menuform.setVisible(true);
                dispose();
        	}
        });
        btnMenu.setForeground(Color.WHITE);
        btnMenu.setFont(new Font("SimSun", Font.BOLD, 18));
        btnMenu.setBackground(new Color(0, 0, 132));
        btnMenu.setBounds(257, 245, 89, 21);
        contentPane.add(btnMenu);
        
        JLabel lblmenu = new JLabel("Go back to Menu?");
        lblmenu.setHorizontalAlignment(SwingConstants.CENTER);
        lblmenu.setForeground(Color.WHITE);
        lblmenu.setFont(new Font("SimSun", Font.BOLD, 20));
        lblmenu.setBounds(32, 236, 226, 40);
        contentPane.add(lblmenu);
    }

    private boolean validateCredentials(String name, String password) {
        return true;
    }

    private boolean deleteData(String name) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/electricity", "root", "5306");

            String deleteBillPaymentsQuery = "DELETE FROM BillPayments WHERE customer_id IN (SELECT customer_id FROM Customers WHERE name=?)";
            PreparedStatement deleteBillPaymentsPs = con.prepareStatement(deleteBillPaymentsQuery);
            deleteBillPaymentsPs.setString(1, name);
            int rowsAffectedInBillPayments = deleteBillPaymentsPs.executeUpdate();
            deleteBillPaymentsPs.close();

            String deleteCustomerQuery = "DELETE FROM Customers WHERE name=?";
            PreparedStatement deleteCustomerPs = con.prepareStatement(deleteCustomerQuery);
            deleteCustomerPs.setString(1, name);
            int rowsAffectedInCustomers = deleteCustomerPs.executeUpdate();
            deleteCustomerPs.close();

            con.close();

            return rowsAffectedInBillPayments > 0 && rowsAffectedInCustomers > 0;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
