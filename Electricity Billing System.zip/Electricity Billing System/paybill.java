package electricityBillingSystem;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.sql.SQLException;

public class paybill extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtname;
    private JTextField txtcid;
    private JTextField tctpno;
    private JTextField txtbno;
    private JTextField txtpdate;
    private JTextField txtunit;
    private JTextField txtamount;
    public static String id;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    paybill frame = new paybill();
    				frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
                    frame.setLocationRelativeTo(null);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public paybill(String iden) {
    	id = iden;
    }
    public paybill() {
    	setTitle("Electricity Billing System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1297, 810);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 132));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel btnheading = new JLabel("PAY YOUR ELECTRICITY BILL");
        btnheading.setFont(new Font("Georgia", Font.BOLD, 50));
        btnheading.setForeground(new Color(255, 255, 255));
        btnheading.setHorizontalAlignment(SwingConstants.CENTER);
        btnheading.setBounds(10, 11, 1263, 86);
        contentPane.add(btnheading);

        JLabel lblname = new JLabel("Full Name");
        lblname.setFont(new Font("SimSun", Font.BOLD, 30));
        lblname.setForeground(new Color(255, 255, 255));
        lblname.setHorizontalAlignment(SwingConstants.RIGHT);
        lblname.setBounds(331, 164, 182, 40);
        contentPane.add(lblname);

        JLabel lblcid = new JLabel("Customer ID");
        lblcid.setHorizontalAlignment(SwingConstants.RIGHT);
        lblcid.setForeground(Color.WHITE);
        lblcid.setFont(new Font("SimSun", Font.BOLD, 30));
        lblcid.setBounds(331, 215, 182, 40);
        contentPane.add(lblcid);

        JLabel lblpno = new JLabel("Phone Number");
        lblpno.setHorizontalAlignment(SwingConstants.RIGHT);
        lblpno.setForeground(Color.WHITE);
        lblpno.setFont(new Font("SimSun", Font.BOLD, 30));
        lblpno.setBounds(290, 266, 223, 40);
        contentPane.add(lblpno);

        JLabel lblbno = new JLabel("Bill Number");
        lblbno.setHorizontalAlignment(SwingConstants.RIGHT);
        lblbno.setForeground(Color.WHITE);
        lblbno.setFont(new Font("SimSun", Font.BOLD, 30));
        lblbno.setBounds(331, 317, 182, 40);
        contentPane.add(lblbno);

        JLabel lblpdate = new JLabel("Payment Date");
        lblpdate.setHorizontalAlignment(SwingConstants.RIGHT);
        lblpdate.setForeground(Color.WHITE);
        lblpdate.setFont(new Font("SimSun", Font.BOLD, 30));
        lblpdate.setBounds(207, 368, 306, 40);
        contentPane.add(lblpdate);

        JLabel lblunit = new JLabel("Units Used");
        lblunit.setHorizontalAlignment(SwingConstants.RIGHT);
        lblunit.setForeground(Color.WHITE);
        lblunit.setFont(new Font("SimSun", Font.BOLD, 30));
        lblunit.setBounds(331, 419, 182, 40);
        contentPane.add(lblunit);

        JLabel lblamount = new JLabel("Amount");
        lblamount.setHorizontalAlignment(SwingConstants.RIGHT);
        lblamount.setForeground(Color.WHITE);
        lblamount.setFont(new Font("SimSun", Font.BOLD, 30));
        lblamount.setBounds(331, 470, 182, 40);
        contentPane.add(lblamount);

        JButton btnpay = new JButton("Pay");
        btnpay.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String password = JOptionPane.showInputDialog(null, "Enter your password for confirmation:");
                if (password != null && !password.isEmpty()) {
                    if (validatePassword(password)) {
                        int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to proceed with the payment?", "Confirmation", JOptionPane.YES_NO_OPTION);
                        if (option == JOptionPane.YES_OPTION) {
                            if (insertPayment()) {
                                JOptionPane.showMessageDialog(null, "Payment successful!");
                                clearFields(); 
                            } else {
                                JOptionPane.showMessageDialog(null, "Payment failed. Please try again.");
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Incorrect password. Please try again.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Payment cancelled.");
                    
                    txtname.setText("");
                    txtcid.setText("");
                    tctpno.setText("");
                    txtbno.setText("");
                    txtpdate.setText("");
                    txtunit.setText("");
                    txtamount.setText("");
                }
            }
        });
        btnpay.setFont(new Font("SimSun", Font.BOLD, 20));
        btnpay.setBackground(new Color(0, 236, 0));
        btnpay.setForeground(new Color(255, 255, 255));
        btnpay.setBounds(634, 530, 130, 40);
        contentPane.add(btnpay);

        JSeparator separator = new JSeparator();
        separator.setOrientation(SwingConstants.VERTICAL);
        separator.setBounds(289, 124, 20, 470);
        contentPane.add(separator);

        JSeparator separator_1 = new JSeparator();
        separator_1.setOrientation(SwingConstants.VERTICAL);
        separator_1.setBounds(1062, 124, 20, 470);
        contentPane.add(separator_1);

        JSeparator separator_2 = new JSeparator();
        separator_2.setBounds(289, 124, 774, 29);
        contentPane.add(separator_2);

        JSeparator separator_2_1 = new JSeparator();
        separator_2_1.setBounds(289, 592, 774, 29);
        contentPane.add(separator_2_1);

        txtname = new JTextField();
        txtname.setFont(new Font("SimSun", Font.BOLD, 15));
        txtname.setColumns(10);
        txtname.setBounds(591, 164, 316, 29);
        contentPane.add(txtname);

        txtcid = new JTextField();
        txtcid.setFont(new Font("SimSun", Font.BOLD, 15));
        txtcid.setColumns(10);
        txtcid.setBounds(591, 215, 316, 29);
        contentPane.add(txtcid);

        tctpno = new JTextField();
        tctpno.setFont(new Font("SimSun", Font.BOLD, 15));
        tctpno.setColumns(10);
        tctpno.setBounds(591, 266, 316, 29);
        contentPane.add(tctpno);

        txtbno = new JTextField();
        txtbno.setFont(new Font("SimSun", Font.BOLD, 15));
        txtbno.setColumns(10);
        txtbno.setBounds(591, 317, 316, 29);
        contentPane.add(txtbno);

        txtpdate = new JTextField();
        txtpdate.setFont(new Font("SimSun", Font.BOLD, 15));
        txtpdate.setColumns(10);
        txtpdate.setBounds(591, 368, 316, 29);
        contentPane.add(txtpdate);

        txtunit = new JTextField();
        txtunit.setFont(new Font("SimSun", Font.BOLD, 15));
        txtunit.setColumns(10);
        txtunit.setBounds(591, 419, 316, 29);
        contentPane.add(txtunit);

        txtamount = new JTextField();
        txtamount.setFont(new Font("SimSun", Font.BOLD, 15));
        txtamount.setColumns(10);
        txtamount.setBounds(591, 470, 316, 29);
        contentPane.add(txtamount);

        JButton btnRetrieve = new JButton("Retrieve");
        btnRetrieve.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = txtname.getText().trim();

                if (!name.isEmpty()) {
                    retrieveData(name);
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a name to retrieve data.");
                }
            }
        });
        btnRetrieve.setForeground(Color.WHITE);
        btnRetrieve.setFont(new Font("SimSun", Font.BOLD, 18));
        btnRetrieve.setBackground(new Color(0, 236, 0));
        btnRetrieve.setBounds(917, 164, 123, 29);
        contentPane.add(btnRetrieve);
        
        JLabel lblmenu = new JLabel("Go back to Menu?");
        lblmenu.setHorizontalAlignment(SwingConstants.CENTER);
        lblmenu.setForeground(Color.WHITE);
        lblmenu.setFont(new Font("SimSun", Font.BOLD, 30));
        lblmenu.setBounds(451, 621, 316, 40);
        contentPane.add(lblmenu);
        
        JButton btnMenu = new JButton("Menu");
        btnMenu.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		menu menuform = new menu();
        		menuform.setLocationRelativeTo(null);
                menuform.setVisible(true);
                dispose();
        	}
        });
        btnMenu.setForeground(Color.WHITE);
        btnMenu.setFont(new Font("SimSun", Font.BOLD, 24));
        btnMenu.setBackground(new Color(0, 0, 132));
        btnMenu.setBounds(777, 621, 130, 40);
        contentPane.add(btnMenu);
        
        txtcid.setEditable(false);
        tctpno.setEditable(false);
        txtbno.setEditable(false);
        txtpdate.setEditable(false);
        txtunit.setEditable(false);
        txtamount.setEditable(false);
    }
    
    private void clearFields() {
        txtname.setText("");
        txtcid.setText("");
        tctpno.setText("");
        txtbno.setText("");
        txtpdate.setText("");
        txtunit.setText("");
        txtamount.setText("");
    }
    
    private boolean insertPayment() {
        try {

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/electricity", "root", "5306");
            
            String query = "INSERT INTO BillPayments (customer_id, bill_no, payment_date, units_used, amount, transaction_id) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, txtcid.getText().trim());
            ps.setString(2, txtbno.getText().trim());
            ps.setString(3, txtpdate.getText().trim());
            ps.setDouble(4, Double.parseDouble(txtunit.getText().trim()));
            ps.setDouble(5, Double.parseDouble(txtamount.getText().trim()));
            ps.setInt(6, generateTransactionID());
           
            int rowsAffected = ps.executeUpdate();
            
            ps.close();
            con.close();
            
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void retrieveData(String name) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/electricity", "root", "5306");

            String query = "SELECT * FROM Customers WHERE name=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, name);

            ResultSet rs = ps.executeQuery();

            boolean billPaid = false; 

            if (rs.next()) {
                int customerId = rs.getInt("customer_id");
                billPaid = isBillPaid(customerId);

                if (billPaid) {
                    JOptionPane.showMessageDialog(null, "Bill already paid");
                    txtname.setText("");
                } else {
                    txtcid.setText(String.valueOf(customerId));
                    tctpno.setText(rs.getString("contact_details"));

                    String fauxBillNumber = "BILL" + generateRandomNumber();
                    txtbno.setText(fauxBillNumber);

                    int fauxUnitsUsed = generateRandomNumber(100, 500);
                    txtunit.setText(String.valueOf(fauxUnitsUsed));

                    double fauxAmount = fauxUnitsUsed * 10.5; 
                    txtamount.setText(String.format("%.2f", fauxAmount));

                    LocalDate currentDate = LocalDate.now();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    String formattedDate = currentDate.format(formatter);
                    txtpdate.setText(formattedDate);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No record found for the provided name.");
            }

            rs.close();
            ps.close();
            con.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    
    private boolean isBillPaid(int customerId) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/electricity", "root", "5306");

            String query = "SELECT * FROM BillPayments WHERE customer_id=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, customerId);

            ResultSet rs = ps.executeQuery();

            boolean paid = rs.next();

            rs.close();
            ps.close();
            con.close();

            return paid;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    private int generateTransactionID() {
        return (int) (Math.random() * (99999999 - 10000000 + 1)) + 10000000;
    }
    
    private int generateRandomNumber() {
        return (int) (Math.random() * (9999 - 1000 + 1)) + 1000;
    }

    private int generateRandomNumber(int min, int max) {
        return (int) (Math.random() * (max - min + 1)) + min;
    }
    
    private boolean validatePassword(String password) {
        try {

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/electricity", "root", "5306");

            String query = "SELECT password_hash FROM customers WHERE name=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, txtname.getText().trim());
          
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {

                String hashedPasswordFromDB = rs.getString("password_hash");

                return password.equals(hashedPasswordFromDB); 
            }

            rs.close();
            ps.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
