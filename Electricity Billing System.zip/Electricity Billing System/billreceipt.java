package electricityBillingSystem;

import java.awt.EventQueue;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class billreceipt extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	public static String id;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					billreceipt frame = new billreceipt();
					frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public billreceipt(String iden) {
		id = iden;
	}
	public billreceipt() {
		setTitle("Electricity Billing System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1297, 810);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 132));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Bill Receipt");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Georgia", Font.BOLD, 50));
		lblNewLabel.setBounds(10, 11, 1263, 91);
		contentPane.add(lblNewLabel);
		
		JLabel lblname = new JLabel("Name");
		lblname.setHorizontalAlignment(SwingConstants.RIGHT);
		lblname.setForeground(Color.WHITE);
		lblname.setFont(new Font("SimSun", Font.BOLD, 18));
		lblname.setBounds(65, 204, 220, 38);
		contentPane.add(lblname);
		
		JLabel lblcid = new JLabel("ID");
		lblcid.setHorizontalAlignment(SwingConstants.RIGHT);
		lblcid.setForeground(Color.WHITE);
		lblcid.setFont(new Font("SimSun", Font.BOLD, 18));
		lblcid.setBounds(55, 168, 230, 38);
		contentPane.add(lblcid);
		
		JLabel lbladd = new JLabel("Address");
		lbladd.setHorizontalAlignment(SwingConstants.LEFT);
		lbladd.setForeground(Color.WHITE);
		lbladd.setFont(new Font("SimSun", Font.BOLD, 18));
		lbladd.setBounds(425, 376, 214, 44);
		contentPane.add(lbladd);
		
		JLabel lblbno = new JLabel("Bill Number");
		lblbno.setHorizontalAlignment(SwingConstants.RIGHT);
		lblbno.setForeground(Color.WHITE);
		lblbno.setFont(new Font("SimSun", Font.BOLD, 18));
		lblbno.setBounds(610, 169, 214, 38);
		contentPane.add(lblbno);
		
		JLabel lblpid = new JLabel("Payment ID");
		lblpid.setHorizontalAlignment(SwingConstants.RIGHT);
		lblpid.setForeground(Color.WHITE);
		lblpid.setFont(new Font("SimSun", Font.BOLD, 18));
		lblpid.setBounds(610, 205, 214, 38);
		contentPane.add(lblpid);
		
		textField = new JTextField();
		textField.setFont(new Font("SimSun", Font.BOLD, 14));
		textField.setColumns(10);
		textField.setBounds(322, 174, 238, 30);
		contentPane.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("SimSun", Font.BOLD, 14));
		textField_1.setColumns(10);
		textField_1.setBounds(322, 212, 238, 30);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("SimSun", Font.BOLD, 14));
		textField_2.setColumns(10);
		textField_2.setBounds(853, 169, 238, 30);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("SimSun", Font.BOLD, 14));
		textField_3.setColumns(10);
		textField_3.setBounds(853, 207, 238, 30);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("SimSun", Font.BOLD, 14));
		textField_4.setColumns(10);
		textField_4.setBounds(655, 307, 238, 30);
		contentPane.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("SimSun", Font.BOLD, 14));
		textField_5.setColumns(10);
		textField_5.setBounds(655, 345, 238, 30);
		contentPane.add(textField_5);
		
		JLabel lblpno = new JLabel("Phone Number");
		lblpno.setHorizontalAlignment(SwingConstants.LEFT);
		lblpno.setForeground(Color.WHITE);
		lblpno.setFont(new Font("SimSun", Font.BOLD, 18));
		lblpno.setBounds(425, 307, 214, 38);
		contentPane.add(lblpno);
		
		JLabel lblmail = new JLabel("Email");
		lblmail.setHorizontalAlignment(SwingConstants.LEFT);
		lblmail.setForeground(Color.WHITE);
		lblmail.setFont(new Font("SimSun", Font.BOLD, 18));
		lblmail.setBounds(425, 343, 214, 38);
		contentPane.add(lblmail);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("SimSun", Font.BOLD, 14));
		textField_6.setColumns(10);
		textField_6.setBounds(655, 384, 238, 30);
		contentPane.add(textField_6);
		
		JLabel lbltid = new JLabel("Transaction ID");
		lbltid.setHorizontalAlignment(SwingConstants.LEFT);
		lbltid.setForeground(Color.WHITE);
		lbltid.setFont(new Font("SimSun", Font.BOLD, 18));
		lbltid.setBounds(425, 491, 214, 44);
		contentPane.add(lbltid);
		
		JLabel lblamount = new JLabel("Amount");
		lblamount.setHorizontalAlignment(SwingConstants.LEFT);
		lblamount.setForeground(Color.WHITE);
		lblamount.setFont(new Font("SimSun", Font.BOLD, 18));
		lblamount.setBounds(425, 458, 214, 38);
		contentPane.add(lblamount);
		
		JLabel lblunit = new JLabel("Units Used");
		lblunit.setHorizontalAlignment(SwingConstants.LEFT);
		lblunit.setForeground(Color.WHITE);
		lblunit.setFont(new Font("SimSun", Font.BOLD, 18));
		lblunit.setBounds(425, 422, 214, 38);
		contentPane.add(lblunit);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("SimSun", Font.BOLD, 14));
		textField_7.setColumns(10);
		textField_7.setBounds(655, 422, 238, 30);
		contentPane.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("SimSun", Font.BOLD, 14));
		textField_8.setColumns(10);
		textField_8.setBounds(655, 460, 238, 30);
		contentPane.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setFont(new Font("SimSun", Font.BOLD, 14));
		textField_9.setColumns(10);
		textField_9.setBounds(655, 499, 238, 30);
		contentPane.add(textField_9);
		
		JLabel lblpdate = new JLabel("Payment Date");
		lblpdate.setHorizontalAlignment(SwingConstants.LEFT);
		lblpdate.setForeground(Color.WHITE);
		lblpdate.setFont(new Font("SimSun", Font.BOLD, 18));
		lblpdate.setBounds(425, 528, 214, 44);
		contentPane.add(lblpdate);
		
		textField_10 = new JTextField();
		textField_10.setFont(new Font("SimSun", Font.BOLD, 14));
		textField_10.setColumns(10);
		textField_10.setBounds(655, 536, 238, 30);
		contentPane.add(textField_10);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(180, 133, 969, 24);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(180, 604, 969, 24);
		contentPane.add(separator_1);
		
		JSeparator separator_1_1 = new JSeparator();
		separator_1_1.setOrientation(SwingConstants.VERTICAL);
		separator_1_1.setBounds(180, 133, 39, 474);
		contentPane.add(separator_1_1);
		
		JSeparator separator_1_1_1 = new JSeparator();
		separator_1_1_1.setOrientation(SwingConstants.VERTICAL);
		separator_1_1_1.setBounds(1147, 133, 39, 474);
		contentPane.add(separator_1_1_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(180, 264, 969, 24);
		contentPane.add(separator_2);
		
		JSeparator separator_1_1_1_1 = new JSeparator();
		separator_1_1_1_1.setOrientation(SwingConstants.VERTICAL);
		separator_1_1_1_1.setBounds(649, 133, 39, 133);
		contentPane.add(separator_1_1_1_1);
		
		JButton btnMenu = new JButton("Menu");
		btnMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu menuform = new menu();
				menuform.setLocationRelativeTo(null);
                menuform.setVisible(true);
                dispose();
			}
		});
		btnMenu.setForeground(Color.WHITE);
		btnMenu.setFont(new Font("SimSun", Font.BOLD, 24));
		btnMenu.setBackground(new Color(0, 0, 132));
		btnMenu.setBounds(751, 627, 130, 40);
		contentPane.add(btnMenu);
		
		JLabel lblmenu = new JLabel("Go back to Menu?");
		lblmenu.setHorizontalAlignment(SwingConstants.CENTER);
		lblmenu.setForeground(Color.WHITE);
		lblmenu.setFont(new Font("SimSun", Font.BOLD, 30));
		lblmenu.setBounds(425, 627, 316, 40);
		contentPane.add(lblmenu);
		
		JButton btngenerate = new JButton("Generate");
		btngenerate.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            int customerId = Integer.parseInt(textField.getText().trim());
		            fillFieldsWithCustomerData(customerId);
		        } catch (NumberFormatException ex) {
		            JOptionPane.showMessageDialog(null, "Please enter a valid customer ID.");
		        }
		    }
		});
		fillFieldsWithCustomerData(Integer.parseInt(id));
		btngenerate.setForeground(Color.WHITE);
		btngenerate.setFont(new Font("SimSun", Font.BOLD, 16));
		btngenerate.setBackground(new Color(0, 0, 132));
		btngenerate.setBounds(568, 560, 0, 1);
		contentPane.add(btngenerate);
		
        textField_1.setEditable(false);
        textField.setEditable(false);
        textField_2.setEditable(false);
        textField_3.setEditable(false);
        textField_4.setEditable(false);
        textField_5.setEditable(false);
        textField_6.setEditable(false);
        textField_7.setEditable(false);
        textField_8.setEditable(false);
        textField_9.setEditable(false);
        textField_10.setEditable(false);
	}
	
	private void fillFieldsWithCustomerData(int customerId) {
	    try {
	        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/electricity", "root", "5306");
	        String query = "SELECT * FROM Customers WHERE customer_id=?";
	        PreparedStatement ps = con.prepareStatement(query);
	        ps.setInt(1, customerId);
	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            textField.setText(rs.getString("customer_id"));
	            textField_1.setText(rs.getString("name"));
	            textField_4.setText(rs.getString("contact_details"));
	            textField_5.setText(rs.getString("email"));
	            textField_6.setText(rs.getString("address"));

	            String billQuery = "SELECT * FROM BillPayments WHERE customer_id=?";
	            PreparedStatement billPs = con.prepareStatement(billQuery);
	            billPs.setInt(1, customerId);
	            ResultSet billRs = billPs.executeQuery();

	            if (billRs.next()) {
	                textField_2.setText(billRs.getString("bill_no"));
	                textField_3.setText(billRs.getString("payment_id"));
	                textField_7.setText(billRs.getString("units_used"));
	                textField_8.setText(billRs.getString("amount"));
	                textField_9.setText(billRs.getString("transaction_id"));
	                textField_10.setText(billRs.getString("payment_date"));
	            } else {
	                textField_2.setText(""); 
	                textField_3.setText("");
	                textField_7.setText(""); 
	                textField_8.setText(""); 
	                textField_9.setText(""); 
	                textField_10.setText("");
	                
	                JOptionPane.showMessageDialog(null, "No bill information found for this customer.");
	            }

	            billRs.close();
	            billPs.close();
	        } else {
	            JOptionPane.showMessageDialog(null, "Invalid customer ID. Please enter a valid customer ID.");
	        }

	        rs.close();
	        ps.close();
	        con.close();
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	}


}
