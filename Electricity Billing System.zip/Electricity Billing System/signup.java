package electricityBillingSystem;

import java.awt.EventQueue;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import librarayManagement.SignIn;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class signup extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField signinname;
	private JTextField signupname;
	private JTextField signupadd;
	private JTextField signupemail;
	private JTextField signupno;
	private JButton btnSignUp;
	private JLabel lblSignUp;
	private JLabel lblElectricity;
	private JLabel lblBilling;
	private JLabel lblSystem;
	private JLabel lblname;
	private JLabel lbladd;
	private JLabel lblemail;
	private JLabel lblno;
	private JLabel lblpass;
	private JLabel lblcpass;
	private JLabel lblNewLabel_1;
	private JSeparator separator;
	private JSeparator separator_1;
	private JSeparator separator_2;
	private JSeparator separator_3;
	private JSeparator separator_4;
	private JLabel lblsigninname;
	private JLabel lblsigninpass;
	private JPasswordField signuppass;
	private JPasswordField signupcpass;
	private JPasswordField signinpass;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signup frame = new signup();
					frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public signup() {
		setTitle("Electricity Billing System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1297, 810);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(255, 255, 255));
		contentPane.setBackground(new Color(0, 0, 132));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("     E-Bill");
		lblNewLabel.setBackground(new Color(0, 0, 255));
		lblNewLabel.setFont(new Font("Georgia", Font.BOLD, 30));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(0, 23, 634, 88);
		contentPane.add(lblNewLabel);
		
		signinname = new JTextField();
		signinname.setFont(new Font("SimSun", Font.BOLD, 16));
		signinname.setBounds(652, 53, 249, 26);
		contentPane.add(signinname);
		signinname.setColumns(10);
		
		JButton btnsignin = new JButton("Sign In");
		btnsignin.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	            String username = signinname.getText().trim();
	            String password = new String(signinpass.getPassword()).trim();

	            try {
	                Class.forName("com.mysql.cj.jdbc.Driver");
	                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/electricity", "root", "5306");

	                String query = "SELECT * FROM Customers WHERE name = '"+username+"' AND password_hash = '"+password+"'";
	                Statement s = con.createStatement();
	                
	                ResultSet rs = s.executeQuery(query);

	                if (rs.next()) {
	                	menu menuform1 = new menu(rs.getInt(1)+"");
	                	menu menuform = new menu();
	                    menuform.setLocationRelativeTo(null);
	                    menuform.setVisible(true);
	                    dispose();
	                } else {
	                    JOptionPane.showMessageDialog(null, "Invalid username or password");
	                }

	                s.close();
	                con.close();
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
	    });

		btnsignin.setFont(new Font("Georgia", Font.BOLD, 14));
		btnsignin.setBackground(new Color(0, 236, 0));
		btnsignin.setForeground(new Color(255, 255, 255));
		btnsignin.setBounds(1169, 52, 89, 26);
		contentPane.add(btnsignin);
		
		signupname = new JTextField();
		signupname.setFont(new Font("SimSun", Font.BOLD, 16));
		signupname.setColumns(10);
		signupname.setBounds(758, 277, 395, 34);
		contentPane.add(signupname);
		
		signupadd = new JTextField();
		signupadd.setFont(new Font("SimSun", Font.BOLD, 16));
		signupadd.setColumns(10);
		signupadd.setBounds(758, 334, 395, 34);
		contentPane.add(signupadd);
		
		signupemail = new JTextField();
		signupemail.setFont(new Font("SimSun", Font.BOLD, 16));
		signupemail.setColumns(10);
		signupemail.setBounds(758, 388, 395, 34);
		contentPane.add(signupemail);
		
		signupno = new JTextField();
		signupno.setFont(new Font("SimSun", Font.BOLD, 16));
		signupno.setColumns(10);
		signupno.setBounds(758, 444, 395, 34);
		contentPane.add(signupno);
		
		btnSignUp = new JButton("Sign Up");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String f1 = signupname.getText().trim();
				String f2 = signupadd.getText().trim();
				String f3 = signupemail.getText().trim();
				String f4 = signupno.getText().trim();
				String f5 = signuppass.getText().trim();
				String f6 = signupcpass.getText().trim();
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
			        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/electricity", "root", "5306");
			        
			        String name = signupname.getText().trim();
			        if (name.isEmpty()) {
			            JOptionPane.showMessageDialog(null, "Name is Empty");
			            return;
			        }
			        if (!name.matches("[a-zA-Z ]+")) {
			            JOptionPane.showMessageDialog(null, "Invalid Name");
			            return; 
			        }
			        
			        String lname = signupadd.getText();
			        if (f2.isEmpty()) {
	                    JOptionPane.showMessageDialog(null, "Address is Empty");
	                    return; 
	                }
			        
			        String email = signupemail.getText();
			        if (f3.isEmpty()) {
	                    JOptionPane.showMessageDialog(null, "Email is Empty");
	                    return; 
	                }
			        if (!email.contains("@") || !email.endsWith(".com")) {
			            JOptionPane.showMessageDialog(null, "Invalid email");
			            return; 
			        }
			        
			        String phone = signupno.getText();
			        if (f4.isEmpty()) {
	                    JOptionPane.showMessageDialog(null, "Phone Number is Empty");
	                    return; 
	                }
			        if (!phone.matches("[0-9]+") || phone.length() != 10) {
			            JOptionPane.showMessageDialog(null, "Invalid Phone Number. Please enter a 10-digit number.");
			            return; 
			        }
			        
			        String password = new String(signuppass.getPassword());
			        String confirmPassword = new String( signupcpass.getPassword());
			        if (f5.isEmpty()) {
	                    JOptionPane.showMessageDialog(null, "Password is Empty");
	                    return; 
	                }
			        if (f6.isEmpty()) {
	                    JOptionPane.showMessageDialog(null, "Confirm Password is Empty");
	                    return; 
	                }
			        if (password.length() != 8) {
			            JOptionPane.showMessageDialog(null, "Password should be of minimum 8 characters.");
			            return; 
			        }
			        if (!password.equals(confirmPassword)) {
			            JOptionPane.showMessageDialog(null, "Passwords does not match");
			            return;
			        }
			        
			        String checkEmailQuery = "SELECT * FROM Customers WHERE email = ?";
			        PreparedStatement checkEmailStmt = con.prepareStatement(checkEmailQuery);
			        checkEmailStmt.setString(1, email);
			        ResultSet emailResultSet = checkEmailStmt.executeQuery();
			        if (emailResultSet.next()) {
			            JOptionPane.showMessageDialog(null, "Email already exists");
			            return; 
			        }
			        
			        String checkUsernameQuery = "SELECT * FROM Customers WHERE contact_details = ?";
			        PreparedStatement checkUsernameStmt = con.prepareStatement(checkUsernameQuery);
			        checkUsernameStmt.setString(1, signupno.getText());
			        ResultSet usernameResultSet = checkUsernameStmt.executeQuery();
			        if (usernameResultSet.next()) {
			            JOptionPane.showMessageDialog(null, "Phone Number already exists");
			            return; 
			        }
			        
			        String query = "INSERT INTO Customers (name, address, contact_details, email, password_hash) VALUES(?,?,?,?,?)";
			        PreparedStatement ps = con.prepareStatement(query);
			        ps.setString(1, signupname.getText());
			        ps.setString(2, signupadd.getText());
			        ps.setLong(3, Long.parseLong(signupno.getText()));
			        ps.setString(4, signupemail.getText());
			        ps.setString(5, signuppass.getText());

			        int i = ps.executeUpdate();
			        
			        JOptionPane.showMessageDialog(null, "Successfully Registered. You can now Sign In");

			        ps.close();
			        con.close();
			        
			        signupname.setText("");
			        signupadd.setText("");
			        signupemail.setText("");
			        signupno.setText("");
			        signuppass.setText("");
			        signupcpass.setText("");
			        
				} catch (Exception e1) {
			        e1.printStackTrace();
			    }
			}
		});
		btnSignUp.setForeground(Color.WHITE);
		btnSignUp.setFont(new Font("Georgia", Font.BOLD, 14));
		btnSignUp.setBackground(new Color(0, 236, 0));
		btnSignUp.setBounds(899, 615, 104, 29);
		contentPane.add(btnSignUp);
		
		lblSignUp = new JLabel("Sign Up");
		lblSignUp.setHorizontalAlignment(SwingConstants.CENTER);
		lblSignUp.setForeground(Color.WHITE);
		lblSignUp.setFont(new Font("Georgia", Font.BOLD, 65));
		lblSignUp.setBackground(Color.BLUE);
		lblSignUp.setBounds(633, 136, 396, 75);
		contentPane.add(lblSignUp);
		
		lblElectricity = new JLabel("Electricity ");
		lblElectricity.setHorizontalAlignment(SwingConstants.CENTER);
		lblElectricity.setForeground(Color.WHITE);
		lblElectricity.setFont(new Font("Georgia", Font.BOLD, 70));
		lblElectricity.setBackground(Color.BLUE);
		lblElectricity.setBounds(9, 381, 474, 81);
		contentPane.add(lblElectricity);
		
		lblBilling = new JLabel("Billing ");
		lblBilling.setHorizontalAlignment(SwingConstants.CENTER);
		lblBilling.setForeground(Color.WHITE);
		lblBilling.setFont(new Font("Georgia", Font.BOLD, 70));
		lblBilling.setBackground(new Color(0, 255, 255));
		lblBilling.setBounds(19, 449, 464, 81);
		contentPane.add(lblBilling);
		
		lblSystem = new JLabel("System");
		lblSystem.setHorizontalAlignment(SwingConstants.CENTER);
		lblSystem.setForeground(Color.WHITE);
		lblSystem.setFont(new Font("Georgia", Font.BOLD, 70));
		lblSystem.setBackground(Color.BLUE);
		lblSystem.setBounds(9, 509, 474, 88);
		contentPane.add(lblSystem);
		
		lblname = new JLabel("Full name");
		lblname.setHorizontalAlignment(SwingConstants.RIGHT);
		lblname.setFont(new Font("SimSun", Font.BOLD, 20));
		lblname.setForeground(new Color(255, 255, 255));
		lblname.setBounds(566, 277, 119, 34);
		contentPane.add(lblname);
		
		lbladd = new JLabel("Address");
		lbladd.setHorizontalAlignment(SwingConstants.RIGHT);
		lbladd.setForeground(Color.WHITE);
		lbladd.setFont(new Font("SimSun", Font.BOLD, 20));
		lbladd.setBounds(566, 334, 119, 34);
		contentPane.add(lbladd);
		
		lblemail = new JLabel("Email");
		lblemail.setHorizontalAlignment(SwingConstants.RIGHT);
		lblemail.setForeground(Color.WHITE);
		lblemail.setFont(new Font("SimSun", Font.BOLD, 20));
		lblemail.setBounds(566, 388, 119, 34);
		contentPane.add(lblemail);
		
		lblno = new JLabel("Contact No.");
		lblno.setHorizontalAlignment(SwingConstants.RIGHT);
		lblno.setForeground(Color.WHITE);
		lblno.setFont(new Font("SimSun", Font.BOLD, 20));
		lblno.setBounds(566, 444, 119, 34);
		contentPane.add(lblno);
		
		lblpass = new JLabel("Password");
		lblpass.setHorizontalAlignment(SwingConstants.RIGHT);
		lblpass.setForeground(Color.WHITE);
		lblpass.setFont(new Font("SimSun", Font.BOLD, 20));
		lblpass.setBounds(566, 500, 119, 34);
		contentPane.add(lblpass);
		
		lblcpass = new JLabel("Confirm Password");
		lblcpass.setHorizontalAlignment(SwingConstants.RIGHT);
		lblcpass.setForeground(Color.WHITE);
		lblcpass.setFont(new Font("SimSun", Font.BOLD, 20));
		lblcpass.setBounds(493, 553, 192, 34);
		contentPane.add(lblcpass);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\aashi\\Downloads\\sign up.png"));
		lblNewLabel_1.setBounds(134, 187, 192, 187);
		contentPane.add(lblNewLabel_1);
		
		separator = new JSeparator();
		separator.setForeground(Color.WHITE);
		separator.setBackground(Color.WHITE);
		separator.setBounds(493, 233, 695, 2);
		contentPane.add(separator);
		
		separator_1 = new JSeparator();
		separator_1.setForeground(Color.WHITE);
		separator_1.setBackground(Color.WHITE);
		separator_1.setBounds(493, 661, 695, 2);
		contentPane.add(separator_1);
		
		separator_2 = new JSeparator();
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setForeground(Color.WHITE);
		separator_2.setBackground(Color.WHITE);
		separator_2.setBounds(494, 233, 2, 430);
		contentPane.add(separator_2);
		
		separator_3 = new JSeparator();
		separator_3.setOrientation(SwingConstants.VERTICAL);
		separator_3.setForeground(Color.WHITE);
		separator_3.setBackground(Color.WHITE);
		separator_3.setBounds(1186, 233, 2, 430);
		contentPane.add(separator_3);
		
		separator_4 = new JSeparator();
		separator_4.setForeground(Color.WHITE);
		separator_4.setBackground(Color.WHITE);
		separator_4.setBounds(20, 99, 1253, 2);
		contentPane.add(separator_4);
		
		lblsigninname = new JLabel("Full Name");
		lblsigninname.setFont(new Font("SimSun", Font.BOLD, 20));
		lblsigninname.setForeground(new Color(255, 255, 255));
		lblsigninname.setBounds(652, 11, 138, 31);
		contentPane.add(lblsigninname);
		
		lblsigninpass = new JLabel("Password");
		lblsigninpass.setForeground(Color.WHITE);
		lblsigninpass.setFont(new Font("SimSun", Font.BOLD, 20));
		lblsigninpass.setBounds(911, 11, 138, 31);
		contentPane.add(lblsigninpass);
		
		signuppass = new JPasswordField();
		signuppass.setBounds(758, 500, 391, 34);
		contentPane.add(signuppass);
		
		signupcpass = new JPasswordField();
		signupcpass.setBounds(758, 553, 391, 34);
		contentPane.add(signupcpass);
		
		signinpass = new JPasswordField();
		signinpass.setBounds(911, 53, 242, 26);
		contentPane.add(signinpass);
		
	}
}
